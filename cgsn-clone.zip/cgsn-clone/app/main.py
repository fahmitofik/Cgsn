import hmac
import logging
from contextlib import asynccontextmanager
from fastapi import BackgroundTasks, FastAPI, HTTPException, Request
from . import db, telegram as tg
from .config import get_settings
from .handler import handle_update

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


@asynccontextmanager
async def lifespan(_: FastAPI):
    await db.init()
    yield
    await tg.close()
    await db.close()


app = FastAPI(title="CGSN CEO Clone", lifespan=lifespan, docs_url=None, redoc_url=None)


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/webhook")
async def webhook(request: Request, background: BackgroundTasks):
    s = get_settings()
    secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
    if not hmac.compare_digest(secret, s.telegram_webhook_secret):
        raise HTTPException(status_code=403, detail="forbidden")
    try:
        update = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="bad json")

    if s.process_inline:           # serverless: work must finish before the response returns
        await handle_update(update)
    else:                          # long-running server: ack fast, process in background
        background.add_task(handle_update, update)
    return {"ok": True}
