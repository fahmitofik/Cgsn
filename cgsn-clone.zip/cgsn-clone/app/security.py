"""Fast, deterministic pre-screen. The LLM adds a second, contextual opinion."""
import re
import time
from collections import defaultdict, deque
from dataclasses import dataclass

LEVELS = {"none": 0, "low": 1, "high": 2, "crisis": 3}


@dataclass
class Flag:
    level: str = "none"
    category: str = ""
    reason: str = ""


def max_level(a: str, b: str) -> str:
    return a if LEVELS.get(a, 0) >= LEVELS.get(b, 0) else b


_CRISIS = re.compile(
    r"\b(kill myself|suicid\w*|want to die|end my life|self[- ]harm|hurt myself|"
    r"overboard|medical emergency|being (assaulted|abused|trafficked)|sexual(ly)? (assault|harass)\w*|"
    r"i('| a)m not safe|help me.{0,20}(emergency|danger))\b", re.I)
_THREAT = re.compile(
    r"\b(i('| wi)ll (kill|hurt|destroy|expose|sue) (you|u|cgsn)|bomb|"
    r"i know where you live|you will regret|death threat)\b", re.I)
_SPAM = re.compile(
    r"(airdrop|crypto giveaway|guaranteed (profit|returns)|double your (money|bitcoin)|"
    r"send (btc|usdt|eth)|investment opportunity|click here to claim|work from home earn|"
    r"t\.me/\+|join my (channel|group)|forex signals|casino|porn|onlyfans)", re.I)
_INJECTION = re.compile(
    r"(ignore (all |your )?(previous|prior|above) (instructions|rules)|reveal (your )?(system )?prompt|"
    r"you are now (dan|an? unrestricted)|jailbreak|developer mode|act as .{0,30}without (rules|restrictions)|"
    r"print your instructions)", re.I)
_ABUSE = re.compile(
    r"\b(fuck (you|off)|stupid (bot|idiot)|scam(mers)?|fraud(sters)?|shut up|piece of (shit|crap)|"
    r"you (idiot|moron|clown))\b", re.I)
_URL = re.compile(r"https?://|www\.|t\.me/", re.I)


def prescreen(text: str) -> Flag:
    if _CRISIS.search(text):
        return Flag("crisis", "safety_crisis", "Possible personal-safety or emergency language")
    if _THREAT.search(text):
        return Flag("high", "threat", "Threatening language directed at you/CGSN")
    if _INJECTION.search(text):
        return Flag("high", "prompt_injection", "Attempt to override or extract bot instructions")
    if _SPAM.search(text) or len(_URL.findall(text)) >= 3 or re.search(r"(.)\1{15,}", text):
        return Flag("low", "spam", "Spam/promotional pattern")
    if _ABUSE.search(text):
        return Flag("low", "toxic", "Abusive language")
    return Flag()


class RateLimiter:
    def __init__(self, limit: int, window: int):
        self.limit, self.window = limit, window
        self.hits: dict[int, deque] = defaultdict(deque)
        self.alerted: dict[int, float] = {}

    def check(self, chat_id: int) -> tuple[bool, bool]:
        """Returns (allowed, first_block_in_window)."""
        now = time.time()
        q = self.hits[chat_id]
        while q and now - q[0] > self.window:
            q.popleft()
        if len(q) >= self.limit:
            first = now - self.alerted.get(chat_id, 0) > self.window
            if first:
                self.alerted[chat_id] = now
            return False, first
        q.append(now)
        return True, False
