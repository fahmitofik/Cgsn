import json
import time
import asyncpg
from .config import get_settings

_pool: asyncpg.Pool | None = None
_kb_cache: dict = {"at": 0.0, "data": None}


async def init():
    global _pool
    # statement_cache_size=0 is required for Supabase's pgbouncer pooler
    _pool = await asyncpg.create_pool(get_settings().database_url, min_size=1, max_size=5,
                                      statement_cache_size=0)


async def close():
    if _pool:
        await _pool.close()


def pool() -> asyncpg.Pool:
    assert _pool, "DB not initialised"
    return _pool


async def claim_update(update_id: int) -> bool:
    """Idempotency: Telegram retries webhooks; process each update once."""
    row = await pool().fetchrow(
        "INSERT INTO processed_updates(update_id) VALUES($1) ON CONFLICT DO NOTHING RETURNING update_id",
        update_id)
    return row is not None


async def get_kb() -> dict:
    now = time.time()
    if _kb_cache["data"] and now - _kb_cache["at"] < get_settings().kb_cache_seconds:
        return _kb_cache["data"]
    p = pool()
    programs = await p.fetch(
        "SELECT name, description, eligibility, duration, fees, application_deadline, apply_url "
        "FROM programs WHERE is_active ORDER BY sort_order, name")
    events = await p.fetch(
        "SELECT title, description, starts_at, ends_at, location, category, registration_url "
        "FROM events WHERE is_active AND COALESCE(ends_at, starts_at) >= now() "
        "ORDER BY starts_at LIMIT 40")
    faqs = await p.fetch(
        "SELECT question, answer, category FROM faqs WHERE is_active ORDER BY category, id")
    data = {"programs": [dict(r) for r in programs],
            "events": [dict(r) for r in events],
            "faqs": [dict(r) for r in faqs]}
    _kb_cache.update(at=now, data=data)
    return data


async def recent_history(chat_id: int, limit: int) -> list[dict]:
    rows = await pool().fetch(
        "SELECT role, content FROM conversation_logs WHERE chat_id=$1 "
        "ORDER BY created_at DESC LIMIT $2", chat_id, limit)
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


async def log_message(chat_id: int, user_id: int | None, username: str | None, full_name: str | None,
                      role: str, content: str, meta: dict | None = None):
    await pool().execute(
        "INSERT INTO conversation_logs(chat_id,user_id,username,full_name,role,content,meta) "
        "VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)",
        chat_id, user_id, username, full_name, role, content, json.dumps(meta or {}))


async def create_incident(kind: str, severity: str, category: str, chat_id: int, user_id: int | None,
                          username: str | None, full_name: str | None, message: str, reason: str):
    await pool().execute(
        "INSERT INTO incidents(kind,severity,category,chat_id,user_id,username,full_name,message,reason) "
        "VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)",
        kind, severity, category, chat_id, user_id, username, full_name, message[:2000], reason)


async def pause_chat(chat_id: int, hours: float):
    await pool().execute(
        "INSERT INTO chat_state(chat_id,paused_until) VALUES($1, now() + make_interval(secs => $2)) "
        "ON CONFLICT (chat_id) DO UPDATE SET paused_until = EXCLUDED.paused_until",
        chat_id, hours * 3600.0)


async def is_paused(chat_id: int) -> bool:
    return bool(await pool().fetchval(
        "SELECT paused_until > now() FROM chat_state WHERE chat_id=$1", chat_id))
