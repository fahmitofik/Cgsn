import json
import logging
from datetime import datetime, timezone
from anthropic import AsyncAnthropic
from .config import get_settings
from .prompts import SYSTEM_PROMPT
from .security import Flag

log = logging.getLogger("brain")
_client: AsyncAnthropic | None = None

FALLBACK = {
    "reply": "Thank you for reaching out. I want this handled properly, so I've logged your message "
             "and it will be reviewed personally. You'll hear back shortly.",
    "kb_grounded": False, "escalate": True, "escalation_reason": "Assistant error / unparsable output",
    "risk": "none", "risk_category": "", "risk_reason": "",
}


def _fmt_dt(v):
    return v.strftime("%a %d %b %Y, %H:%M UTC") if hasattr(v, "strftime") else (str(v) if v else "TBA")


def render_kb(kb: dict) -> str:
    out = ["### PROGRAMS"]
    for p in kb["programs"] or []:
        out.append(f"- {p['name']}: {p['description']} | Eligibility: {p['eligibility'] or 'TBA'} | "
                   f"Duration: {p['duration'] or 'TBA'} | Fees: {p['fees'] or 'TBA'} | "
                   f"Deadline: {_fmt_dt(p['application_deadline'])} | Apply: {p['apply_url'] or 'n/a'}")
    out.append("\n### UPCOMING SCHEDULE & TIMELINES")
    for e in kb["events"] or []:
        out.append(f"- {e['title']} [{e['category'] or 'general'}] {_fmt_dt(e['starts_at'])}"
                   f"{' → ' + _fmt_dt(e['ends_at']) if e['ends_at'] else ''} | {e['location'] or 'TBA'} | "
                   f"{e['description'] or ''} | Register: {e['registration_url'] or 'n/a'}")
    out.append("\n### FAQ (canonical answers)")
    for f in kb["faqs"] or []:
        out.append(f"Q: {f['question']}\nA: {f['answer']}")
    if not (kb["programs"] or kb["events"] or kb["faqs"]):
        out.append("(Knowledge base is empty — escalate everything substantive.)")
    return "\n".join(out)


def _client_() -> AsyncAnthropic:
    global _client
    if _client is None:
        _client = AsyncAnthropic(api_key=get_settings().anthropic_api_key)
    return _client


def _build_messages(history: list[dict], user_text: str) -> list[dict]:
    msgs: list[dict] = []
    for h in history + [{"role": "user", "content": user_text}]:
        role = "assistant" if h["role"] == "assistant" else "user"
        if msgs and msgs[-1]["role"] == role:
            msgs[-1]["content"] += "\n" + h["content"]
        else:
            msgs.append({"role": role, "content": h["content"]})
    while msgs and msgs[0]["role"] != "user":
        msgs.pop(0)
    return msgs


def _parse(raw: str) -> dict:
    raw = raw.strip()
    start, end = raw.find("{"), raw.rfind("}")
    data = json.loads(raw[start:end + 1])
    out = {**FALLBACK, **data}
    out["escalate"] = bool(out.get("escalate"))
    if out.get("risk") not in ("none", "low", "high", "crisis"):
        out["risk"] = "none"
    out["reply"] = str(out.get("reply") or "")
    return out


async def think(user_text: str, history: list[dict], kb: dict, sender_name: str, flag: Flag) -> dict:
    s = get_settings()
    system = (SYSTEM_PROMPT
              .replace("{{FOUNDER}}", s.founder_name)
              .replace("{{ORG}}", s.org_name)
              .replace("{{NOW}}", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"))
              .replace("{{PRESCREEN}}", f"{flag.level}/{flag.category}: {flag.reason}" if flag.category else "none")
              .replace("{{KB}}", render_kb(kb)))
    messages = _build_messages(history, f"[Sender: {sender_name}]\n{user_text}")
    try:
        resp = await _client_().messages.create(
            model=s.anthropic_model, max_tokens=700, system=system, messages=messages)
        raw = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
        return _parse(raw)
    except Exception:
        log.exception("LLM call/parse failed")
        return dict(FALLBACK)
