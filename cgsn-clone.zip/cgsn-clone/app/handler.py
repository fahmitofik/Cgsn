import logging
from . import brain, db, security, telegram as tg
from .config import get_settings
from .security import max_level

log = logging.getLogger("handler")
_limiter: security.RateLimiter | None = None


def limiter() -> security.RateLimiter:
    global _limiter
    if _limiter is None:
        s = get_settings()
        _limiter = security.RateLimiter(s.rate_limit_msgs, s.rate_limit_window)
    return _limiter


async def handle_update(update: dict):
    try:
        if "business_message" in update:
            await _business_message(update["update_id"], update["business_message"])
        elif "business_connection" in update:
            c = update["business_connection"]
            log.info("business_connection id=%s enabled=%s user=%s", c.get("id"),
                     c.get("is_enabled"), (c.get("user") or {}).get("id"))
        elif "message" in update:
            await _direct_message(update["message"])
    except Exception:
        log.exception("Unhandled error processing update %s", update.get("update_id"))


async def _direct_message(msg: dict):
    """Messages sent straight to the bot (not business). /id helps you find ADMIN_CHAT_ID."""
    text = (msg.get("text") or "").strip().lower()
    if text in ("/start", "/id"):
        await tg.send_plain(msg["chat"]["id"], f"Your chat ID: {msg['chat']['id']}\nUser ID: {(msg.get('from') or {}).get('id')}")


async def _business_message(update_id: int, msg: dict):
    s = get_settings()
    bcid = msg.get("business_connection_id")
    if not bcid:
        return
    chat_id = msg["chat"]["id"]
    sender = msg.get("from") or {}
    sender_id = sender.get("id")
    username = sender.get("username")
    full_name = " ".join(filter(None, [sender.get("first_name"), sender.get("last_name")])) or "Unknown"
    display = f"{full_name} (@{username})" if username else full_name

    # Owner replied manually -> human takeover, pause the clone in this chat
    if sender_id == s.owner_user_id:
        if s.handoff_hours > 0:
            await db.pause_chat(chat_id, s.handoff_hours)
        return
    if sender.get("is_bot"):
        return
    if not await db.claim_update(update_id):
        return  # duplicate delivery

    text = (msg.get("text") or msg.get("caption") or "").strip()[: s.max_input_chars]

    if await db.is_paused(chat_id):
        if text:
            await db.log_message(chat_id, sender_id, username, full_name, "user", text, {"paused": True})
        return

    if not text:
        await tg.send_business_message(
            chat_id, "Thanks for your message. I can only read text for now — could you type your question?", bcid)
        return

    # --- flood control ---
    allowed, first_block = limiter().check(chat_id)
    if not allowed:
        if first_block:
            await _flag("high", "flood", chat_id, sender_id, username, full_name, text,
                        "Message flood / rate limit exceeded", kind="security")
            await tg.notify_admin("Suspicious activity", user=display, user_id=sender_id, chat_id=chat_id,
                                  category="flood", reason="Rate limit exceeded", excerpt=text, severity="high")
        return

    # --- deterministic pre-screen ---
    flag = security.prescreen(text)
    history = await db.recent_history(chat_id, s.history_turns)
    await db.log_message(chat_id, sender_id, username, full_name, "user", text,
                         {"prescreen": flag.category or None})

    if flag.category == "spam":  # silent drop
        await _flag("low", "spam", chat_id, sender_id, username, full_name, text, flag.reason, kind="security")
        return

    await tg.send_typing(chat_id, bcid)
    kb = await db.get_kb()
    res = await brain.think(text, history, kb, display, flag)

    risk = max_level(flag.level, res["risk"])
    category = res.get("risk_category") or flag.category or "other"
    reason = res.get("risk_reason") or flag.reason or "Flagged by safety filter"

    # --- security / crisis alerts ---
    if risk in ("high", "crisis"):
        await _flag(risk, category, chat_id, sender_id, username, full_name, text, reason, kind="security")
        await tg.notify_admin("CRISIS ALERT" if risk == "crisis" else "Suspicious activity",
                              user=display, user_id=sender_id, chat_id=chat_id, category=category,
                              reason=reason, excerpt=text, severity=risk)
    elif risk == "low":
        await _flag("low", category, chat_id, sender_id, username, full_name, text, reason, kind="security")

    # --- executive escalation ---
    if res["escalate"] and risk not in ("high", "crisis"):
        why = res.get("escalation_reason") or "Outside knowledge base / needs executive input"
        await _flag("normal", "escalation", chat_id, sender_id, username, full_name, text, why, kind="escalation")
        await tg.notify_admin("Inquiry needs you", user=display, user_id=sender_id, chat_id=chat_id,
                              category="escalation", reason=why, excerpt=text, severity="escalation")

    # --- reply as the CEO (native business reply) ---
    reply = res["reply"].strip()
    if reply:
        try:
            await tg.send_business_message(chat_id, reply, bcid)
            await db.log_message(chat_id, None, None, "CEO clone", "assistant", reply,
                                 {"escalate": res["escalate"], "risk": risk, "kb_grounded": res.get("kb_grounded")})
        except Exception:
            log.exception("Failed to send reply")
            await tg.notify_admin("Reply delivery failed", user=display, user_id=sender_id, chat_id=chat_id,
                                  category="delivery", reason="Telegram rejected the reply", excerpt=text,
                                  severity="high")


async def _flag(severity, category, chat_id, user_id, username, full_name, text, reason, kind):
    try:
        await db.create_incident(kind, severity, category, chat_id, user_id, username, full_name, text, reason)
    except Exception:
        log.exception("Failed to store incident")
