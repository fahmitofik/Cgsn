import html
import logging
import httpx
from .config import get_settings

log = logging.getLogger("telegram")
_client: httpx.AsyncClient | None = None


def client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        _client = httpx.AsyncClient(timeout=20)
    return _client


async def close():
    global _client
    if _client:
        await _client.aclose()
        _client = None


async def _call(method: str, payload: dict) -> dict:
    url = f"https://api.telegram.org/bot{get_settings().telegram_bot_token}/{method}"
    r = await client().post(url, json=payload)
    data = r.json()
    if not data.get("ok"):
        log.error("Telegram %s failed: %s", method, data)
        raise RuntimeError(f"Telegram error: {data.get('description')}")
    return data


async def send_business_message(chat_id: int, text: str, business_connection_id: str):
    """Reply natively as the account owner (requires business_connection_id)."""
    return await _call("sendMessage", {
        "chat_id": chat_id,
        "text": text[:4096],
        "business_connection_id": business_connection_id,
    })


async def send_typing(chat_id: int, business_connection_id: str):
    try:
        await _call("sendChatAction", {
            "chat_id": chat_id,
            "action": "typing",
            "business_connection_id": business_connection_id,
        })
    except Exception:
        pass  # cosmetic only


async def send_plain(chat_id: int, text: str):
    return await _call("sendMessage", {"chat_id": chat_id, "text": text[:4096]})


async def notify_admin(title: str, *, user: str, user_id, chat_id, category: str,
                       reason: str, excerpt: str, severity: str):
    emoji = {"crisis": "🚨", "high": "⚠️", "escalation": "📌"}.get(severity, "ℹ️")
    e = html.escape
    text = (
        f"{emoji} <b>{e(title)}</b>\n"
        f"<b>Severity:</b> {e(severity)}  |  <b>Category:</b> {e(category)}\n"
        f"<b>User:</b> {e(user)}\n"
        f"<b>User ID:</b> <code>{user_id}</code>\n"
        f"<b>Chat ID:</b> <code>{chat_id}</code>\n"
        f"<b>Issue:</b> {e(reason)}\n"
        f"<b>Message:</b> <i>{e(excerpt[:600])}</i>\n"
        f"<a href=\"tg://user?id={user_id}\">Open profile</a>"
    )
    try:
        await _call("sendMessage", {
            "chat_id": get_settings().admin_chat_id,
            "text": text[:4096],
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        })
    except Exception:
        log.exception("Failed to notify admin")
