from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    telegram_bot_token: str
    telegram_webhook_secret: str
    admin_chat_id: int
    owner_user_id: int
    database_url: str
    anthropic_api_key: str
    anthropic_model: str = "claude-sonnet-5-5"
    founder_name: str = "the Founder"
    org_name: str = "CGSN (Cruise Global Scholars Network)"
    kb_cache_seconds: int = 60
    history_turns: int = 10
    rate_limit_msgs: int = 8
    rate_limit_window: int = 60
    max_input_chars: int = 2000
    handoff_hours: float = 4
    process_inline: bool = False


@lru_cache
def get_settings() -> Settings:
    return Settings()
