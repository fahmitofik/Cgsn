-- CGSN CEO Clone — run in Supabase SQL Editor

create table if not exists programs (
  id bigint generated always as identity primary key,
  name text not null,
  description text not null,
  eligibility text,
  duration text,
  fees text,
  application_deadline timestamptz,
  apply_url text,
  sort_order int default 100,
  is_active boolean default true,
  updated_at timestamptz default now()
);

create table if not exists events (
  id bigint generated always as identity primary key,
  title text not null,
  description text,
  category text,                       -- e.g. intake, webinar, academic, deadline, voyage
  starts_at timestamptz not null,
  ends_at timestamptz,
  location text,
  registration_url text,
  is_active boolean default true,
  updated_at timestamptz default now()
);
create index if not exists events_start_idx on events (starts_at) where is_active;

create table if not exists faqs (
  id bigint generated always as identity primary key,
  category text,
  question text not null,
  answer text not null,
  is_active boolean default true,
  updated_at timestamptz default now()
);

create table if not exists conversation_logs (
  id bigint generated always as identity primary key,
  chat_id bigint not null,
  user_id bigint,
  username text,
  full_name text,
  role text not null check (role in ('user','assistant')),
  content text not null,
  meta jsonb default '{}'::jsonb,
  created_at timestamptz default now()
);
create index if not exists convo_chat_idx on conversation_logs (chat_id, created_at desc);

create table if not exists incidents (          -- escalations + security flags
  id bigint generated always as identity primary key,
  kind text not null check (kind in ('escalation','security')),
  severity text not null,                       -- low | normal | high | crisis
  category text,
  chat_id bigint not null,
  user_id bigint,
  username text,
  full_name text,
  message text,
  reason text,
  status text default 'open',                   -- open | resolved
  created_at timestamptz default now()
);
create index if not exists incidents_open_idx on incidents (status, created_at desc);

create table if not exists processed_updates (  -- webhook idempotency
  update_id bigint primary key,
  created_at timestamptz default now()
);

create table if not exists chat_state (         -- human-takeover pause
  chat_id bigint primary key,
  paused_until timestamptz
);

-- Lock down the REST API; the backend connects with the DB role (bypasses RLS)
alter table programs enable row level security;
alter table events enable row level security;
alter table faqs enable row level security;
alter table conversation_logs enable row level security;
alter table incidents enable row level security;
alter table processed_updates enable row level security;
alter table chat_state enable row level security;

-- SAMPLE DATA — replace with your real CGSN content
insert into programs (name, description, eligibility, duration, fees, application_deadline, apply_url) values
('Sample Scholars Program', 'REPLACE ME: flagship CGSN scholars experience.', 'REPLACE ME', 'REPLACE ME', 'REPLACE ME', now() + interval '60 days', 'https://example.com/apply');
insert into events (title, description, category, starts_at, location) values
('Sample Info Webinar', 'REPLACE ME', 'webinar', now() + interval '14 days', 'Online');
insert into faqs (category, question, answer) values
('general', 'What is CGSN?', 'REPLACE ME with the canonical answer.');
