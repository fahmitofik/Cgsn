# CGSN CEO Digital Twin — Telegram Business Webhook

## 1. Telegram setup
1. Your account needs **Telegram Premium**. Create a bot in @BotFather → `/mybots` → Bot Settings → **Business Mode: ON**.
2. In Telegram: Settings → Business → **Chatbots** → add your bot, choose which chats it can reply to, and allow "Reply to messages".
3. Message your bot privately and send `/id` (after deploy) to get your user/chat ID → `ADMIN_CHAT_ID` and `OWNER_USER_ID`.
   (The bot can only DM you alerts after you've pressed Start.)

## 2. Supabase
Create a project → SQL Editor → run `schema.sql`. Replace the sample rows with real CGSN programs, events, FAQs
(edit live in Table Editor; the bot refreshes its cache every 60s).
Use the **Transaction pooler** connection string (port 6543) as `DATABASE_URL`, ending in `?sslmode=require`.

## 3. Deploy on Render (recommended)
1. Push this folder to GitHub → Render → New → Blueprint (uses `render.yaml`) → fill secret env vars (see `.env.example`).
2. Use an always-on plan (free tier sleeps → delayed replies).
3. Register the webhook (replace values):
```
curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook" \
  -d "url=https://<your-service>.onrender.com/webhook" \
  -d "secret_token=<TELEGRAM_WEBHOOK_SECRET>" \
  -d 'allowed_updates=["business_message","business_connection","message"]'
```
4. Verify: `curl https://api.telegram.org/bot<TOKEN>/getWebhookInfo`

## 4. Vercel (alternative)
Set `PROCESS_INLINE=true` (serverless freezes after the response, so background tasks would be killed), add all env vars,
`vercel --prod`, then run the same `setWebhook` call with the Vercel URL. Mind function timeouts (raise `maxDuration` on Pro).

## 5. Local test
```
pip install -r requirements.txt && cp .env.example .env
uvicorn app.main:app --reload   # expose with: ngrok http 8000
```

## Notes
- **Human takeover:** when you reply manually in a chat, the clone pauses there for `HANDOFF_HOURS`. Test this once in your
  account; set `HANDOFF_HOURS=0` to disable.
- **Security:** webhook is verified via secret header; updates are de-duplicated; per-chat flood limit; regex pre-screen + LLM risk grading.
  Incidents are stored in `incidents` and pushed to your admin chat.
- **System prompt:** `app/prompts.py`.
